package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

public class PlayerESP extends ModuleBase {

    private final Setting.ColorSetting   color      = new Setting.ColorSetting("Color", "Box color", 0xCC4488FF);
    private final Setting.BooleanSetting filled     = new Setting.BooleanSetting("Filled", "Draw filled boxes", false);
    private final Setting.BooleanSetting showHealth = new Setting.BooleanSetting("Health", "Show health label", true);
    private final Setting.BooleanSetting showDist   = new Setting.BooleanSetting("Distance", "Show distance label", true);

    public PlayerESP() {
        super("Player ESP", "Draws boxes around other players", ModuleCategory.ESP);
        registerSetting(color);
        registerSetting(filled);
        registerSetting(showHealth);
        registerSetting(showDist);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        var cam = mc.gameRenderer.getMainCamera().getPosition();

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            AABB bb = p.getBoundingBox();
            double ox = -cam.x, oy = -cam.y, oz = -cam.z;
            int col = color.getEffectiveColor();
            if (filled.getValue())
                RenderUtil.drawFilledBox(e.getPoseStack(), e.getConsumers(),
                    bb.minX + ox, bb.minY + oy, bb.minZ + oz,
                    bb.maxX + ox, bb.maxY + oy, bb.maxZ + oz,
                    col & 0x33FFFFFF);
            RenderUtil.drawBox(e.getPoseStack(), e.getConsumers(),
                bb.minX + ox, bb.minY + oy, bb.minZ + oz,
                bb.maxX + ox, bb.maxY + oy, bb.maxZ + oz, col);
        }
    }
}
