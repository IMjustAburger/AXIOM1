package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Predicts an approximate pearl arc on the client tick thread, then draws the
 * cached path during world rendering. The render callback does not query blocks.
 */
public class PearlTrajectory extends ModuleBase {

    private static final double GRAVITY = 0.03;
    private static final double DRAG = 0.99;
    private static final double SPEED = 1.5;

    private final Setting.ColorSetting color =
            new Setting.ColorSetting("Color", "Trajectory line color", 0xCCFF8800);
    private final Setting.IntSetting maxSteps =
            new Setting.IntSetting("Steps", "Simulation steps", 120, 20, 200);

    private List<Vec3> worldPoints = List.of();

    public PearlTrajectory() {
        super("Pearl Trajectory", "Simulates ender pearl throw arc", ModuleCategory.ESP);
        registerSetting(color);
        registerSetting(maxSteps);
    }

    @Override protected void onEnable() { worldPoints = List.of(); }
    @Override protected void onDisable() { worldPoints = List.of(); }

    @EventHandler
    public void onTick(EventTick event) {
        if (event.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            worldPoints = List.of();
            return;
        }

        Vec3 origin = mc.player.getEyePosition(1.0f);
        Vec3 look = mc.player.getLookAngle().scale(SPEED);
        double px = origin.x, py = origin.y, pz = origin.z;
        double vx = look.x, vy = look.y, vz = look.z;
        List<Vec3> points = new ArrayList<>(maxSteps.getValue());

        for (int i = 0; i < maxSteps.getValue(); i++) {
            vy -= GRAVITY;
            vx *= DRAG;
            vy *= DRAG;
            vz *= DRAG;
            px += vx;
            py += vy;
            pz += vz;
            points.add(new Vec3(px, py, pz));

            BlockPos blockPos = BlockPos.containing(px, py, pz);
            if (!mc.level.isOutsideBuildHeight(blockPos.getY())
                    && mc.level.getBlockState(blockPos).isSolid()) {
                break;
            }
        }
        worldPoints = List.copyOf(points);
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        if (worldPoints.size() < 2) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        Vec3 camera = mc.gameRenderer.getMainCamera().getPosition();
        List<Vec3> cameraRelative = new ArrayList<>(worldPoints.size());
        for (Vec3 point : worldPoints) {
            cameraRelative.add(point.subtract(camera));
        }
        RenderUtil.drawLines(event.getPoseStack(), event.getConsumers(),
                cameraRelative, color.getEffectiveColor());
    }
}
