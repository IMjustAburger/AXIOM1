package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import java.util.ArrayList;
import java.util.List;

public class OreESP extends ModuleBase {

    private final Setting.BooleanSetting diamonds = new Setting.BooleanSetting("Diamonds",      "Highlight diamond ore",     true);
    private final Setting.BooleanSetting emeralds = new Setting.BooleanSetting("Emeralds",      "Highlight emerald ore",     true);
    private final Setting.BooleanSetting ancient  = new Setting.BooleanSetting("Ancient Debris","Highlight ancient debris",  true);
    private final Setting.BooleanSetting gold      = new Setting.BooleanSetting("Gold",          "Highlight gold ore",        false);
    private final Setting.IntSetting     radius    = new Setting.IntSetting("Radius", "Search radius", 32, 8, 96);

    private final List<OreEntry> ores = new ArrayList<>();
    private int tick = 0;

    public OreESP() {
        super("Ore ESP", "Highlights ore blocks through terrain", ModuleCategory.ESP);
        registerSetting(diamonds);
        registerSetting(emeralds);
        registerSetting(ancient);
        registerSetting(gold);
        registerSetting(radius);
    }

    @Override protected void onEnable()  { ores.clear(); }
    @Override protected void onDisable() { ores.clear(); }

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (++tick >= 15) { tick = 0; scan(mc); }

        var cam = mc.gameRenderer.getMainCamera().getPosition();
        for (OreEntry oe : ores) {
            double ox = oe.pos.getX() - cam.x;
            double oy = oe.pos.getY() - cam.y;
            double oz = oe.pos.getZ() - cam.z;
            RenderUtil.drawBox(e.getPoseStack(), e.getConsumers(), ox, oy, oz, ox + 1, oy + 1, oz + 1, oe.color);
        }
    }

    private void scan(Minecraft mc) {
        ores.clear();
        Level level = mc.level;
        BlockPos c  = mc.player.blockPosition();
        int r = radius.getValue();
        for (int x = c.getX()-r; x <= c.getX()+r; x++)
        for (int y = -64; y <= 16; y++)
        for (int z = c.getZ()-r; z <= c.getZ()+r; z++) {
            BlockPos bp = new BlockPos(x, y, z);
            int col = getColor(level.getBlockState(bp).getBlock());
            if (col != 0) ores.add(new OreEntry(bp, col));
        }
    }

    private int getColor(Block b) {
        if (diamonds.getValue() && (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE)) return 0xCC00FFFF;
        if (emeralds.getValue() && (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE)) return 0xCC00FF44;
        if (ancient.getValue()  &&  b == Blocks.ANCIENT_DEBRIS) return 0xCCFF4400;
        if (gold.getValue()     && (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE)) return 0xCCFFD700;
        return 0;
    }

    private record OreEntry(BlockPos pos, int color) {}
}
