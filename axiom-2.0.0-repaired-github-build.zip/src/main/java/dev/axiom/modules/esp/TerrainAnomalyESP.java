package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender2D;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import dev.axiom.core.world.ChunkAnomaly;
import dev.axiom.core.world.ScanQueue;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class TerrainAnomalyESP extends ModuleBase {

    private final Setting.BooleanSetting showLabels = new Setting.BooleanSetting("Labels",     "Show anomaly type labels",  true);
    private final Setting.BooleanSetting showConf   = new Setting.BooleanSetting("Confidence", "Show confidence %",          true);
    private final Setting.EnumSetting<Setting.Sensitivity> minConf =
        new Setting.EnumSetting<>("Min Confidence", "Minimum confidence to display",
            Setting.Sensitivity.MEDIUM, Setting.Sensitivity.class);
    private final Setting.IntSetting maxRange = new Setting.IntSetting("Max Range", "Max render range", 256, 32, 512);

    public TerrainAnomalyESP() {
        super("Terrain Anomaly ESP", "Visualises WorldScanner anomalies", ModuleCategory.ESP);
        registerSetting(showLabels);
        registerSetting(showConf);
        registerSetting(minConf);
        registerSetting(maxRange);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        double threshold = minConf.getValue().toConfidenceThreshold();
        double maxR = maxRange.getValue();
        var cam = mc.gameRenderer.getMainCamera().getPosition();

        for (List<ChunkAnomaly> list : ScanQueue.getInstance().getAllAnomalies()) {
            for (ChunkAnomaly a : list) {
                if (a.confidence < threshold) continue;
                double cx = a.pos.getMiddleBlockX(), cz = a.pos.getMiddleBlockZ();
                if (Math.abs(cx - mc.player.getX()) > maxR || Math.abs(cz - mc.player.getZ()) > maxR) continue;

                int col = RenderUtil.confidenceColor(a.confidence);
                double x1 = a.pos.getMinBlockX()   - cam.x;
                double z1 = a.pos.getMinBlockZ()   - cam.z;
                double x2 = a.pos.getMaxBlockX()+1 - cam.x;
                double z2 = a.pos.getMaxBlockZ()+1 - cam.z;
                double oy = mc.player.getY() - cam.y;
                RenderUtil.drawFilledBox(e.getPoseStack(), e.getConsumers(), x1, oy-2, z1, x2, oy+30, z2, col & 0x22FFFFFF);
                RenderUtil.drawBox(e.getPoseStack(), e.getConsumers(),       x1, oy-2, z1, x2, oy+30, z2, col);
            }
        }
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (!showLabels.getValue()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        double threshold = minConf.getValue().toConfidenceThreshold();

        for (List<ChunkAnomaly> list : ScanQueue.getInstance().getAllAnomalies()) {
            for (ChunkAnomaly a : list) {
                if (a.confidence < threshold) continue;
                Vec3 world = new Vec3(a.pos.getMiddleBlockX(), mc.player.getY() + 15, a.pos.getMiddleBlockZ());
                float[] sc = RenderUtil.worldToScreen(world);
                if (sc == null) continue;
                String text = a.type.label + (showConf.getValue()
                    ? " (" + String.format("%.0f", a.confidence * 100) + "%)" : "");
                int tw = mc.font.width(text);
                RenderUtil.drawRect(e.getGraphics(), (int)sc[0]-tw/2-2, (int)sc[1]-2, tw+4, 10, 0x88000000);
                RenderUtil.drawText(e.getGraphics(), text, (int)sc[0]-tw/2, (int)sc[1],
                    RenderUtil.confidenceColor(a.confidence), true);
            }
        }
    }
}
