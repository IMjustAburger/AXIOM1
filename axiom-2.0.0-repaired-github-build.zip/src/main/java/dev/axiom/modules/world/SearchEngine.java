package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class SearchEngine extends ModuleBase {

    private final Setting.IntSetting     searchRadius  = new Setting.IntSetting("Search Radius","Radius to search around player",64,16,256);
    private final Setting.BooleanSetting searchChests  = new Setting.BooleanSetting("Chests",        "Search for chests and barrels", true);
    private final Setting.BooleanSetting searchOres    = new Setting.BooleanSetting("Rare Ores",     "Search for diamond/emerald/ancient debris", true);
    private final Setting.BooleanSetting searchCrafted = new Setting.BooleanSetting("Crafted Blocks","Search for crafted/unnatural blocks", false);

    private final List<BlockPos> found = new CopyOnWriteArrayList<>();
    private int tickCounter = 0;

    public SearchEngine() {
        super("Search Engine", "Locates specific blocks in loaded chunks", ModuleCategory.WORLD);
        registerSetting(searchRadius);
        registerSetting(searchChests);
        registerSetting(searchOres);
        registerSetting(searchCrafted);
    }

    @Override protected void onEnable()  { found.clear(); }
    @Override protected void onDisable() { found.clear(); }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        found.clear();
        Level level     = mc.level;
        BlockPos center = mc.player.blockPosition();
        int r           = searchRadius.getValue();

        for (int x = center.getX()-r; x <= center.getX()+r; x+=2) {
            for (int y = -64; y <= 320; y+=2) {
                for (int z = center.getZ()-r; z <= center.getZ()+r; z+=2) {
                    BlockPos bp = new BlockPos(x, y, z);
                    Block b = level.getBlockState(bp).getBlock();
                    if (matches(b)) found.add(bp);
                }
            }
        }
    }

    private boolean matches(Block b) {
        if (searchChests.getValue() &&
            (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL)) return true;
        if (searchOres.getValue() &&
            (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE ||
             b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE ||
             b == Blocks.ANCIENT_DEBRIS)) return true;
        if (searchCrafted.getValue() &&
            (b == Blocks.CRAFTING_TABLE || b == Blocks.FURNACE || b == Blocks.ENCHANTING_TABLE ||
             b == Blocks.ANVIL || b == Blocks.OBSIDIAN)) return true;
        return false;
    }

    public List<BlockPos> getFound() { return found; }
}
