package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.world.ChunkAnomaly;
import dev.axiom.core.world.ScanQueue;
import net.minecraft.core.ChunkPos;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BaseMap extends ModuleBase {

    private final Setting.EnumSetting<Setting.Sensitivity> sensitivity =
        new Setting.EnumSetting<>("Confidence Filter","Minimum confidence level to display",
            Setting.Sensitivity.MEDIUM, Setting.Sensitivity.class);
    private final Setting.BooleanSetting clusterNearby =
        new Setting.BooleanSetting("Cluster Nearby","Group adjacent chunk anomalies", true);
    private final Setting.IntSetting maxMarkers =
        new Setting.IntSetting("Max Markers","Maximum anomaly markers on map",200,10,1000);

    private final Map<Long, BaseMarker> markers = new ConcurrentHashMap<>();

    public BaseMap() {
        super("Base Map", "Builds a live map of suspected base locations", ModuleCategory.WORLD);
        registerSetting(sensitivity);
        registerSetting(clusterNearby);
        registerSetting(maxMarkers);
    }

    @Override protected void onEnable() {
        markers.clear();
        ScanQueue.getInstance().setOnNewAnomalies(this::onAnomalies);
    }

    @Override protected void onDisable() { markers.clear(); }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        while (markers.size() > maxMarkers.getValue()) {
            Long oldest = markers.entrySet().stream()
                .min(Comparator.comparingLong(en -> en.getValue().detectedAt))
                .map(Map.Entry::getKey).orElse(null);
            if (oldest != null) markers.remove(oldest);
            else break;
        }
    }

    private void onAnomalies(List<ChunkAnomaly> anomalies) {
        double threshold = sensitivity.getValue().toConfidenceThreshold();
        for (ChunkAnomaly a : anomalies) {
            if (a.confidence >= threshold)
                markers.put(a.pos.toLong(), new BaseMarker(a.pos, a.type, a.confidence));
        }
    }

    public Collection<BaseMarker> getMarkers() { return markers.values(); }
    public void clearMarkers() { markers.clear(); }

    public static class BaseMarker {
        public final ChunkPos pos;
        public final ChunkAnomaly.Type type;
        public final double confidence;
        public final long detectedAt = System.currentTimeMillis();

        public BaseMarker(ChunkPos pos, ChunkAnomaly.Type type, double confidence) {
            this.pos = pos; this.type = type; this.confidence = confidence;
        }
        public int x() { return pos.getMiddleBlockX(); }
        public int z() { return pos.getMiddleBlockZ(); }
    }
}
