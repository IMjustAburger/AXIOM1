package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.event.events.EventChunkUnload;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.world.ChunkAnomaly;
import dev.axiom.core.world.ScanQueue;
import net.minecraft.client.Minecraft;
import net.minecraft.core.ChunkPos;

import java.util.HashSet;
import java.util.Set;

import java.util.List;

public class WorldScanner extends ModuleBase {

    private final Setting.EnumSetting<Setting.Sensitivity> sensitivity =
        new Setting.EnumSetting<>("Sensitivity", "Detection sensitivity level",
            Setting.Sensitivity.MEDIUM, Setting.Sensitivity.class);

    private final Setting.EnumSetting<Setting.Preset> preset =
        new Setting.EnumSetting<>("Scan Preset", "Performance vs quality preset",
            Setting.Preset.BALANCED, Setting.Preset.class);

    private final Setting.IntSetting scanMinY =
        new Setting.IntSetting("Scan Min Y", "Lowest Y level to scan", -60, -64, 320);

    private final Setting.IntSetting scanMaxY =
        new Setting.IntSetting("Scan Max Y", "Highest Y level to scan", 64, -64, 320);

    private final Setting.BooleanSetting autoScan =
        new Setting.BooleanSetting("Auto Scan", "Automatically scan newly loaded chunks", true);

    private final Set<Long> reportedChunks = new HashSet<>();
    private int foundCount = 0;

    public WorldScanner() {
        super("World Scanner", "Scans terrain for base remnants and anomalies", ModuleCategory.WORLD);
        registerSetting(sensitivity);
        registerSetting(preset);
        registerSetting(scanMinY);
        registerSetting(scanMaxY);
        registerSetting(autoScan);
    }

    @Override protected void onEnable() {
        ScanQueue q = ScanQueue.getInstance();
        q.setMinY(scanMinY.getValue());
        q.setMaxY(scanMaxY.getValue());
        q.setConfidenceThreshold(sensitivity.getValue().toConfidenceThreshold());
        q.setChunksPerTick(chunksPerTick(preset.getValue()));
        q.setOnNewAnomalies(this::onAnomalies);
        q.start();
        // Seed a small area already in the local client cache. This does not
        // ask the server for additional chunks or access unloaded terrain.
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level != null && minecraft.player != null) {
            ChunkPos center = minecraft.player.chunkPosition();
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    int x = center.x + dx;
                    int z = center.z + dz;
                    if (minecraft.level.hasChunk(x, z)) q.enqueue(new ChunkPos(x, z));
                }
            }
        }
    }

    @Override protected void onDisable() {
        ScanQueue.getInstance().stop();
        reportedChunks.clear();
        foundCount = 0;
    }

    @EventHandler
    public void onChunkLoad(EventChunkLoad e) {
        if (!autoScan.getValue()) return;
        ScanQueue.getInstance().enqueue(e.getChunk().getPos());
    }

    @EventHandler
    public void onChunkUnload(EventChunkUnload e) {
        ScanQueue.getInstance().invalidate(e.getPos());
        reportedChunks.remove(e.getPos().toLong());
        foundCount = reportedChunks.size();
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        ScanQueue q = ScanQueue.getInstance();
        q.setMinY(scanMinY.getValue());
        q.setMaxY(scanMaxY.getValue());
        q.setConfidenceThreshold(sensitivity.getValue().toConfidenceThreshold());
        q.setChunksPerTick(chunksPerTick(preset.getValue()));
        q.processPending(Minecraft.getInstance());
    }

    private static int chunksPerTick(Setting.Preset value) {
        return switch (value) {
            case LOW -> 1;
            case BALANCED -> 2;
            case HIGH -> 4;
        };
    }

    private void onAnomalies(List<ChunkAnomaly> anomalies) {
        if (anomalies == null || anomalies.isEmpty()) return;
        reportedChunks.add(anomalies.getFirst().pos.toLong());
        foundCount = reportedChunks.size();
    }

    public int getFoundCount() { return foundCount; }
    public void clearFound() {
        foundCount = 0;
        reportedChunks.clear();
        ScanQueue.getInstance().clear();
    }
}
