package dev.axiom.modules.utility;

import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * MiddleClickFriend — middle-click a player entity to add them to a local friends list.
 * The list is used by other modules (e.g. KillAura) to skip friends.
 * Full click-detection requires a MixinMouseHandler hook; the list API is complete here.
 */
public class MiddleClickFriend extends ModuleBase {

    private final List<UUID> friends = new ArrayList<>();

    public MiddleClickFriend() {
        super("Middle Click Friend", "Middle-click a player to add them to your friends list", ModuleCategory.UTILITY);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    public void addFriend(UUID uuid)    { if (!friends.contains(uuid)) friends.add(uuid); }
    public void removeFriend(UUID uuid) { friends.remove(uuid); }
    public boolean isFriend(UUID uuid)  { return friends.contains(uuid); }
    public List<UUID> getFriends()      { return Collections.unmodifiableList(friends); }
}
