package dev.axiom.core.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Reads a currently loaded chunk and delegates the scoring rules to ChunkScoring. */
public final class ChunkAnalyzer {

    private static final Set<Block> CRAFTED = Set.of(
        Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.SHULKER_BOX,
        Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX,
        Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX,
        Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.LIGHT_GRAY_SHULKER_BOX,
        Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX,
        Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX,
        Blocks.BLACK_SHULKER_BOX, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
        Blocks.CRAFTING_TABLE, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
        Blocks.ENCHANTING_TABLE, Blocks.BEACON, Blocks.END_PORTAL_FRAME,
        Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN, Blocks.REINFORCED_DEEPSLATE,
        Blocks.NETHER_PORTAL, Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER,
        Blocks.STONECUTTER, Blocks.GRINDSTONE, Blocks.LOOM, Blocks.CARTOGRAPHY_TABLE
    );

    private static final Set<Block> STORAGE_BLOCKS = Set.of(
        Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL,
        Blocks.SHULKER_BOX, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX,
        Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX,
        Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX,
        Blocks.LIGHT_GRAY_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX,
        Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX,
        Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX
    );

    private static final Set<Block> ORE_BLOCKS = Set.of(
        Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.ANCIENT_DEBRIS
    );

    private ChunkAnalyzer() {}

    public static List<ChunkAnomaly> analyze(LevelChunk chunk, int minY, int maxY) {
        if (chunk == null) return List.of();

        int worldMinY = chunk.getLevel().getMinY();
        int worldMaxY = chunk.getLevel().getMaxY() - 1;
        int scanMinY = Math.max(minY, worldMinY);
        int scanMaxY = Math.min(maxY, worldMaxY);
        if (scanMinY > scanMaxY) return List.of();

        ChunkPos chunkPos = chunk.getPos();
        int airCount = 0;
        int totalBlocks = 0;
        int craftedCount = 0;
        int storageCount = 0;
        int rareOreCount = 0;

        // Mutable positions avoid allocating a new BlockPos for every block.
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int x = chunkPos.getMinBlockX(); x <= chunkPos.getMaxBlockX(); x++) {
            for (int z = chunkPos.getMinBlockZ(); z <= chunkPos.getMaxBlockZ(); z++) {
                // WORLD_SURFACE is the first available block position above
                // the terrain. Excluding everything above it prevents ordinary
                // open sky from being misclassified as a dug-out area.
                int surfaceY = chunk.getHeight(Heightmap.Types.WORLD_SURFACE,
                        x & 15, z & 15);
                int columnMaxY = Math.min(scanMaxY, surfaceY - 1);
                if (columnMaxY < scanMinY) continue;

                for (int y = scanMinY; y <= columnMaxY; y++) {
                    Block block = chunk.getBlockState(cursor.set(x, y, z)).getBlock();
                    totalBlocks++;

                    if (block == Blocks.AIR || block == Blocks.CAVE_AIR || block == Blocks.VOID_AIR) {
                        airCount++;
                    }
                    if (CRAFTED.contains(block)) craftedCount++;
                    if (STORAGE_BLOCKS.contains(block)) storageCount++;
                    if (ORE_BLOCKS.contains(block)) rareOreCount++;
                }
            }
        }

        ChunkScoring.Stats stats = new ChunkScoring.Stats(
                totalBlocks, airCount, craftedCount, storageCount, rareOreCount);
        List<ChunkAnomaly> anomalies = new ArrayList<>();
        for (ChunkScoring.Signal signal : ChunkScoring.score(stats)) {
            anomalies.add(new ChunkAnomaly(
                    chunkPos,
                    ChunkAnomaly.Type.valueOf(signal.kind().name()),
                    signal.confidence(),
                    signal.detail()));
        }
        return List.copyOf(anomalies);
    }
}
