package dev.axiom.core.event.events;
import dev.axiom.core.event.Event;
public class EventTick extends Event {
    public enum Phase { PRE, POST }
    private final Phase phase;
    public EventTick(Phase phase) { this.phase = phase; }
    public Phase getPhase() { return phase; }
}
