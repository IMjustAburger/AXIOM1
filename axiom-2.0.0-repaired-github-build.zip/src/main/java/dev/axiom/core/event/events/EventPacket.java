package dev.axiom.core.event.events;

import dev.axiom.core.event.Event;
import dev.axiom.core.event.ICancellable;
import net.minecraft.network.protocol.Packet;

public class EventPacket extends Event implements ICancellable {

    public enum Direction { INBOUND, OUTBOUND }

    private final Packet<?> packet;
    private final Direction direction;
    private boolean cancelled = false;

    public EventPacket(Packet<?> p, Direction d) { packet = p; direction = d; }

    public Packet<?> getPacket()     { return packet; }
    public Direction getDirection()  { return direction; }

    @Override public boolean isCancelled()           { return cancelled; }
    @Override public void    setCancelled(boolean c) { cancelled = c; }
}
