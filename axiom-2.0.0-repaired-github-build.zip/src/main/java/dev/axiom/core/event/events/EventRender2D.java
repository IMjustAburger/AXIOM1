package dev.axiom.core.event.events;
import dev.axiom.core.event.Event;
import net.minecraft.client.gui.GuiGraphics;
public class EventRender2D extends Event {
    private final GuiGraphics graphics;
    private final float partialTick;
    public EventRender2D(GuiGraphics g, float pt) { graphics = g; partialTick = pt; }
    public GuiGraphics getGraphics()   { return graphics; }
    public float       getPartialTick(){ return partialTick; }
}
