package dev.axiom.core.event;

/** Marker interface indicating an event can be cancelled to suppress default behaviour. */
public interface ICancellable {
    boolean isCancelled();
    void    setCancelled(boolean cancelled);
    default void cancel() { setCancelled(true); }
}
