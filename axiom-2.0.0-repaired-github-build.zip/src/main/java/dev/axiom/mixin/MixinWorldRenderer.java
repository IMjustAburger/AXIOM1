package dev.axiom.mixin;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.event.events.EventRender2D;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hooks the 1.21.11 HUD render method. */
@Mixin(Gui.class)
public class MixinWorldRenderer {

    @Inject(method = "render", at = @At("TAIL"))
    private void axiom$onRender2D(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        float partialTick = deltaTracker.getGameTimeDeltaPartialTick(false);
        AxiomClient.getEventBus().post(new EventRender2D(guiGraphics, partialTick));
    }
}
