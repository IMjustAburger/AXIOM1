package dev.axiom.mixin;

import dev.axiom.core.module.ModuleManager;
import dev.axiom.modules.render.FreeLook;
import net.minecraft.client.Camera;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class MixinCamera {

    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "setup", at = @At("TAIL"))
    private void onSetupPost(Level level, Entity entity,
                              boolean detached, boolean invertedView,
                              float partialTick, CallbackInfo ci) {
        FreeLook fl = ModuleManager.getInstance().getModule(FreeLook.class);
        if (fl == null || !fl.isEnabled() || !fl.isHeld()) return;

        Camera self = (Camera)(Object) this;
        // Apply free-look offsets on top of normal yaw/pitch
        float baseYaw   = self.getYRot();
        float basePitch = self.getXRot();
        setRotation(baseYaw + fl.getYawOffset(), basePitch + fl.getPitchOffset());
    }
}
