package dev.axiom.mixin;

import dev.axiom.core.module.ModuleManager;
import dev.axiom.modules.render.FreeLook;
import net.minecraft.client.MouseHandler;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public class MixinMouseHandler {

    /** Previous cursor position — used to compute per-frame delta. */
    @Shadow private double xpos;
    @Shadow private double ypos;

    @Inject(method = "onMove", at = @At("HEAD"), cancellable = true)
    private void onMouseMove(long windowPtr, double newX, double newY, CallbackInfo ci) {
        FreeLook fl = ModuleManager.getInstance().getModule(FreeLook.class);
        if (fl == null || !fl.isEnabled()) return;

        // Update the hold-key state every frame
        boolean held = GLFW.glfwGetKey(windowPtr, fl.getHoldKey()) == GLFW.GLFW_PRESS;
        fl.setHeld(held);
        if (!held) return;

        // Compute raw delta from the shadowed previous position
        double dx = newX - this.xpos;
        double dy = newY - this.ypos;

        // Feed into FreeLook (it scales internally)
        fl.accumulate(dx * 0.15, dy * 0.15);

        // Let the original handler update xpos/ypos and accumulate vanilla mouse
        // deltas. MixinMouseHandler cancels turnPlayer while held, and MixinCamera
        // applies these offsets only to the rendered camera.
    }

    /** Keep mouse movement from rotating the player while FreeLook owns the camera. */
    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void axiom$preventPlayerTurn(double timeDelta, CallbackInfo ci) {
        FreeLook fl = ModuleManager.getInstance().getModule(FreeLook.class);
        if (fl != null && fl.isEnabled() && fl.isHeld()) {
            ci.cancel();
        }
    }
}
