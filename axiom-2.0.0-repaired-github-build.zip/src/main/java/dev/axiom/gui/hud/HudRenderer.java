package dev.axiom.gui.hud;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender2D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.module.ModuleManager;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/**
 * HUD Renderer — draws the module list and status bar in the corner.
 * Subscribes directly to the EventBus (not a module, always active).
 */
public class HudRenderer {

    private static final int TEXT_COLOR   = 0xFFEEEEEE;
    private static final int SHADOW_COLOR = 0xFF111111;
    private static final int BG_COLOR     = 0x99111111;
    private static final int ACCENT       = 0xFF4488FF;

    public HudRenderer() {
        AxiomClient.getEventBus().subscribe(this);
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.renderDebug) return;          // hide with F3

        GuiGraphics gg    = e.getGraphics();
        int sw            = mc.getWindow().getGuiScaledWidth();

        // ── Watermark ────────────────────────────────────────────────────────
        String watermark = "AXIOM v2.0";
        int ww = mc.font.width(watermark) + 8;
        RenderUtil.drawRect(gg, sw - ww - 2, 2, ww, 12, BG_COLOR);
        RenderUtil.drawBorder(gg, sw - ww - 2, 2, ww, 12, ACCENT);
        RenderUtil.drawText(gg, watermark, sw - ww + 2, 5, ACCENT, true);

        // ── Module list (enabled modules, right-side) ─────────────────────
        List<ModuleBase> enabled = ModuleManager.getInstance().getAll().stream()
            .filter(ModuleBase::isEnabled)
            .filter(ModuleBase::isVisible)
            .sorted((a, b) -> mc.font.width(b.getName()) - mc.font.width(a.getName()))
            .toList();

        int y = 2;
        for (ModuleBase m : enabled) {
            int tw = mc.font.width(m.getName());
            int rx = sw - tw - 6;
            RenderUtil.drawRect(gg, rx - 2, y, tw + 6, 11, BG_COLOR);
            // Category accent bar on the right edge
            int accent = categoryColor(m.getCategory());
            RenderUtil.drawRect(gg, sw - 2, y, 2, 11, accent);
            RenderUtil.drawText(gg, m.getName(), rx, y + 2, TEXT_COLOR, true);
            y += 12;
        }
    }

    private int categoryColor(ModuleCategory cat) {
        return switch (cat) {
            case WORLD    -> 0xFF44FF44;
            case ESP      -> 0xFF4488FF;
            case COMBAT   -> 0xFFFF4444;
            case MOVEMENT -> 0xFFFFD700;
            case RENDER   -> 0xFFFF69B4;
            case UTILITY  -> 0xFFAAAAAA;
        };
    }
}
