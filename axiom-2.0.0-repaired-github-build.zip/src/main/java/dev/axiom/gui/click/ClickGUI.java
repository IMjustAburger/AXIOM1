package dev.axiom.gui.click;

import dev.axiom.core.config.ConfigManager;
import dev.axiom.core.config.Setting;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.module.ModuleManager;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * AXIOM ClickGUI — opened with INSERT (bound in AxiomClient).
 *
 * Layout: one panel per category, draggable, left-click to toggle module,
 * right-click to expand settings panel.
 */
public class ClickGUI extends Screen {

    // ── Panel state ───────────────────────────────────────────────────────────
    private static final int PANEL_W   = 140;
    private static final int HEADER_H  = 14;
    private static final int MODULE_H  = 11;
    private static final int SETTING_H = 18;

    private static final int COL_BG       = 0xCC111111;
    private static final int COL_HEADER   = 0xFF1A2744;
    private static final int COL_ACCENT   = 0xFF4488FF;
    private static final int COL_ON       = 0xFF44FF88;
    private static final int COL_OFF      = 0xFF555555;
    private static final int COL_TEXT     = 0xFFEEEEEE;
    private static final int COL_SUBTEXT  = 0xFFAAAAAA;

    private final Map<ModuleCategory, PanelState> panels = new EnumMap<>(ModuleCategory.class);
    private Setting<?> activeSlider;
    private int activeSliderX;
    private int activeSliderWidth;

    private static final int[] COLOR_PRESETS = {
        0xCCFFD700, 0xCC44FF88, 0xCC4488FF, 0xCCFF69B4,
        0xCCFF5555, 0xCCAA66FF, 0xCCFFFFFF
    };

    public ClickGUI() {
        super(Component.literal("AXIOM"));
        int x = 4;
        for (ModuleCategory cat : ModuleCategory.values()) {
            panels.put(cat, new PanelState(x, 4));
            x += PANEL_W + 4;
        }
    }

    // ── Screen lifecycle ──────────────────────────────────────────────────────

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
        // Dim background
        gg.fill(0, 0, width, height, 0x88000000);
        super.render(gg, mouseX, mouseY, partialTick);

        for (ModuleCategory cat : ModuleCategory.values()) {
            drawPanel(gg, cat, mouseX, mouseY);
        }
    }

    private void drawPanel(GuiGraphics gg, ModuleCategory cat, int mx, int my) {
        PanelState state = panels.get(cat);
        List<ModuleBase> modules = ModuleManager.getInstance().getByCategory(cat);

        int px = state.x, py = state.y;
        int panelH = HEADER_H;
        for (ModuleBase m : modules) {
            panelH += MODULE_H;
            if (state.expanded(m)) {
                panelH += m.getSettings().size() * SETTING_H + 2;
            }
        }

        // Panel background
        RenderUtil.drawRect(gg, px, py, PANEL_W, panelH, COL_BG);
        RenderUtil.drawBorder(gg, px, py, PANEL_W, panelH, COL_ACCENT);

        // Header
        RenderUtil.drawRect(gg, px, py, PANEL_W, HEADER_H, COL_HEADER);
        RenderUtil.drawText(gg, cat.displayName, px + 4, py + 3, COL_ACCENT, true);

        int ry = py + HEADER_H;
        for (ModuleBase m : modules) {
            boolean on = m.isEnabled();
            boolean hov = mx >= px && mx < px + PANEL_W && my >= ry && my < ry + MODULE_H;

            RenderUtil.drawRect(gg, px, ry, PANEL_W, MODULE_H, hov ? 0xAA223344 : 0x00000000);
            // Enabled indicator bar
            RenderUtil.drawRect(gg, px, ry, 2, MODULE_H, on ? COL_ON : COL_OFF);
            RenderUtil.drawText(gg, m.getName(), px + 6, ry + 2, on ? COL_TEXT : COL_OFF, false);

            ry += MODULE_H;

            if (state.expanded(m)) {
                for (Setting<?> s : m.getSettings()) {
                    drawSetting(gg, s, px + 4, ry, PANEL_W - 4);
                    if (!s.getDescription().isBlank()
                            && mx >= px + 2 && mx < px + PANEL_W - 2
                            && my >= ry && my < ry + SETTING_H) {
                        drawSettingTooltip(gg, s.getDescription(), mx, my);
                    }
                    ry += SETTING_H;
                }
                ry += 2;
            }
        }
    }

    private void drawSetting(GuiGraphics gg, Setting<?> s, int x, int y, int w) {
        String label = s.getName() + ": " + formatValue(s);
        RenderUtil.drawText(gg, label, x, y + 1, COL_SUBTEXT, false);

        if (s instanceof Setting.DoubleSetting ds) {
            drawSlider(gg, x + 2, y + 12, w - 6,
                    (ds.getValue() - ds.getMin()) / (ds.getMax() - ds.getMin()));
        } else if (s instanceof Setting.IntSetting is) {
            drawSlider(gg, x + 2, y + 12, w - 6,
                    (double) (is.getValue() - is.getMin()) / (is.getMax() - is.getMin()));
        } else if (s instanceof Setting.ColorSetting cs) {
            RenderUtil.drawRect(gg, x + w - 18, y + 2, 14, 10, cs.getValue());
            RenderUtil.drawBorder(gg, x + w - 18, y + 2, 14, 10, COL_TEXT);
        }
    }

    private void drawSettingTooltip(GuiGraphics gg, String description, int mouseX, int mouseY) {
        String message = description;
        int maxWidth = Math.max(80, Math.min(220, width - 12));
        while (message.length() > 8 && font.width(message) > maxWidth - 10) {
            message = message.substring(0, message.length() - 1);
        }
        if (!message.equals(description) && message.length() > 3) {
            message = message.substring(0, message.length() - 3) + "...";
        }
        int boxWidth = Math.min(maxWidth, font.width(message) + 10);
        int x = Math.min(width - boxWidth - 4, mouseX + 10);
        int y = Math.max(4, mouseY - 17);
        RenderUtil.drawRect(gg, x, y, boxWidth, 15, 0xF0101828);
        RenderUtil.drawBorder(gg, x, y, boxWidth, 15, COL_ACCENT);
        RenderUtil.drawText(gg, message, x + 5, y + 4, COL_TEXT, false);
    }

    private void drawSlider(GuiGraphics gg, int x, int y, int width, double amount) {
        if (width <= 0) return;
        double t = Math.max(0.0, Math.min(1.0, amount));
        RenderUtil.drawRect(gg, x, y, width, 3, 0x66555555);
        RenderUtil.drawRect(gg, x, y, (int) Math.round(t * width), 3, COL_ACCENT);
    }

    private String formatValue(Setting<?> s) {
        Object v = s.getValue();
        if (s instanceof Setting.ColorSetting color) {
            return color.isRainbow() ? "Rainbow" : String.format("#%08X", color.getValue());
        }
        if (v instanceof Boolean b) return b ? "ON" : "OFF";
        if (v instanceof Double d)  return String.format("%.2f", d);
        if (v instanceof Enum<?> e) {
            if (e instanceof Setting.Sensitivity sens) return sens.label;
            if (e instanceof Setting.Preset p)        return p.label;
            return e.name();
        }
        return String.valueOf(v);
    }

    // ── Mouse input ───────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        activeSlider = null;
        for (ModuleCategory cat : ModuleCategory.values()) {
            PanelState state   = panels.get(cat);
            List<ModuleBase> modules = ModuleManager.getInstance().getByCategory(cat);
            int px = state.x, py = state.y;

            // Header drag start
            if (button == 0 && mx >= px && mx < px + PANEL_W && my >= py && my < py + HEADER_H) {
                state.dragging = true;
                state.dragOffX = (int)(mx - px);
                state.dragOffY = (int)(my - py);
                return true;
            }

            int ry = py + HEADER_H;
            for (ModuleBase m : modules) {
                if (my >= ry && my < ry + MODULE_H && mx >= px && mx < px + PANEL_W) {
                    if (button == 0) m.toggle();
                    else if (button == 1) state.toggleExpanded(m);
                    return true;
                }
                ry += MODULE_H;

                if (state.expanded(m)) {
                    for (Setting<?> s : m.getSettings()) {
                        if (my >= ry && my < ry + SETTING_H && mx >= px && mx < px + PANEL_W) {
                            handleSettingClick(s, (int) mx, px + 4, ry, PANEL_W - 8, button);
                            return true;
                        }
                        ry += SETTING_H;
                    }
                    ry += 2;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && activeSlider != null) {
            updateSlider(activeSlider, mx, activeSliderX, activeSliderWidth);
            return true;
        }
        for (PanelState state : panels.values()) {
            if (state.dragging) {
                state.x = (int)mx - state.dragOffX;
                state.y = (int)my - state.dragOffY;
                return true;
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        panels.values().forEach(p -> p.dragging = false);
        activeSlider = null;
        return super.mouseReleased(mx, my, button);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void handleSettingClick(Setting<?> setting, int mouseX, int rowX,
                                    int rowY, int rowWidth, int button) {
        if (setting instanceof Setting.BooleanSetting booleanSetting) {
            if (button == 0) booleanSetting.toggle();
        } else if (setting instanceof Setting.EnumSetting enumSetting) {
            if (button == 0) enumSetting.cycleNext();
        } else if (setting instanceof Setting.IntSetting || setting instanceof Setting.DoubleSetting) {
            activeSlider = setting;
            activeSliderX = rowX + 2;
            activeSliderWidth = rowWidth - 6;
            updateSlider(setting, mouseX, activeSliderX, activeSliderWidth);
        } else if (setting instanceof Setting.ColorSetting colorSetting) {
            if (button == 0) {
                colorSetting.setRainbow(!colorSetting.isRainbow());
            } else if (button == 1) {
                int current = colorSetting.getValue();
                int next = COLOR_PRESETS[0];
                for (int i = 0; i < COLOR_PRESETS.length; i++) {
                    if (COLOR_PRESETS[i] == current) {
                        next = COLOR_PRESETS[(i + 1) % COLOR_PRESETS.length];
                        break;
                    }
                }
                colorSetting.setRainbow(false);
                colorSetting.setValue(next);
            }
        }
    }

    private void updateSlider(Setting<?> setting, double mouseX, int startX, int width) {
        if (width <= 0) return;
        double amount = Math.max(0.0, Math.min(1.0, (mouseX - startX) / width));
        if (setting instanceof Setting.IntSetting integerSetting) {
            int value = integerSetting.getMin()
                    + (int) Math.round(amount * (integerSetting.getMax() - integerSetting.getMin()));
            integerSetting.setValue(value);
        } else if (setting instanceof Setting.DoubleSetting doubleSetting) {
            double value = doubleSetting.getMin()
                    + amount * (doubleSetting.getMax() - doubleSetting.getMin());
            doubleSetting.setValue(value);
        }
    }

    @Override
    public void onClose() {
        ConfigManager.getInstance().save();
        super.onClose();
    }

    // ── Panel state ───────────────────────────────────────────────────────────

    private static class PanelState {
        int x, y;
        boolean dragging   = false;
        int     dragOffX   = 0, dragOffY = 0;
        final java.util.Set<String> expandedModules = new java.util.HashSet<>();

        PanelState(int x, int y) { this.x = x; this.y = y; }

        boolean expanded(ModuleBase m)     { return expandedModules.contains(m.getName()); }
        void    toggleExpanded(ModuleBase m) {
            if (!expandedModules.remove(m.getName())) expandedModules.add(m.getName());
        }
    }
}
