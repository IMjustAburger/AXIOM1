@echo off
REM bootstrap-wrapper.bat — Windows equivalent of bootstrap-wrapper.sh
REM Run once after extracting the ZIP to generate gradle-wrapper.jar.
REM Requirements: JDK 21+, internet access, Gradle on PATH.

set REQUIRED_VERSION=8.11
set WRAPPER_JAR=gradle\wrapper\gradle-wrapper.jar

echo === Chimera Gradle wrapper bootstrap ===

if exist "%WRAPPER_JAR%" (
    echo Wrapper JAR already exists at %WRAPPER_JAR% -- nothing to do.
    exit /b 0
)

where gradle >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ERROR: 'gradle' not found on PATH.
    echo.
    echo Install Gradle %REQUIRED_VERSION% from: https://gradle.org/releases/
    echo Or use sdkman / scoop / chocolatey.
    echo.
    echo Alternatively, copy an existing gradle-wrapper.jar from any Fabric
    echo mod project into gradle\wrapper\ and skip this script.
    exit /b 1
)

echo Generating wrapper JAR with Gradle %REQUIRED_VERSION% ...
gradle wrapper --gradle-version %REQUIRED_VERSION%

if exist "%WRAPPER_JAR%" (
    echo.
    echo SUCCESS -- %WRAPPER_JAR% created.
    echo You can now build with: gradlew.bat build
) else (
    echo ERROR: wrapper generation failed.
    exit /b 1
)
