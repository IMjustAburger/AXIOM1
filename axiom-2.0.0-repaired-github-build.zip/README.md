# AXIOM 2.0.0

AXIOM is a Fabric client-side Minecraft mod project targeting Minecraft Java Edition 1.21.11.

## Build

The repository includes a GitHub Actions workflow at `.github/workflows/build.yml`. Push to `main`/`master` or manually run **Actions → Build AXIOM → Run workflow**. The workflow installs Java 21 and Gradle 9.2.1, runs the JUnit tests and Gradle build, then publishes `axiom-2.0.0.jar` as a workflow artifact when the build succeeds.

For local build instructions, see [BUILD_AND_INSTALL.md](BUILD_AND_INSTALL.md).

## Status

The source has not yet been compiled or launched against Minecraft in this environment. Read [FEATURE_REPORT.md](FEATURE_REPORT.md) for the source audit, changes, and known runtime risks.
